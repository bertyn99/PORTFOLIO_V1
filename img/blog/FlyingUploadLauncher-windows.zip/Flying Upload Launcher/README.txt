Hi and welcome to Flying Upload. We will make your uploading faster and easier!
You are just a few steps away from uploading your designs automatically:
Please be aware that Windows Defender / Mac GateKeeper or other anti virus programs
can misjudge Flying Upload. Please allow Flying Upload to be executed as a "normal"
program. If it still does not work, you can contact us. We will help you.

 => Installation Tutorial: https://flyingupload.com/installation-tutorial-windows/

Starting on WINDOWS:
1. Right mouseclick on the downloaded Flying Upload ZIP folder 
   ---> Select "extract all" ---> Choose your folder and click "extract"
   Note: As long as the ZIP folder isn�t extracted you can�t start Flying Upload 
   
2. Navigate into the folder where you have extracted Flying Upload and double click
   the Flying Upload Launcher.exe (EXE) ---> Now the Launcher should start

3. Now go to https://www.flyingupload.com/user-account/ and copy the license key
   from the package into your Launcher ---> click "Start"

4. Just wait, Flying Uplpoad will check if everything is valid and afterwards it
   is installing the main program ---> After installing successful the new main
   window with "Edit" and "Delete" opens
   Note: - You can now already start to edit your designs. Your information will
           be saved in .xml files in the folder of the designs
         - The Amazon Merch Settings are very unique and special and are implemented
           directly in the Edit Window. This data will also be saved in the .xml file.
           After saving your Amazon settings you can start uploading on Merch by Amazon
           
5. Go into the menue bar "Options" and "Settings".
   - In "General" you can choose your favourite mode and the speed at uploading.
     For "Fast" upload a stable connection and an upload speed from 50 Mbit/s is
     recommended, otherwise the tool could be to fast
   - In "Templates" choose the platform and deposit your templates for the specifications 
     you want. If the template can�t be found the default template is chosen
   - For Spreadshirt you have to enter you commission. All other commissions for the
     other platforms are in the deposited template or at RedBubble directly under the
     commission option
   Note: To make it simple and easy for the user we don�t offer an option to choose
     every colour and every commission for every product on every platform.
     Otherwise it would just be confusing
   - Save your settings

6. You are now ready to start! Click on upload in the main window, choose your edited
   designs, agree to our terms and start uploading!


Disclaimer: We tested the tool for over 12 months without having issues with automated
uploading. Nevertheless we can�t guarantee that single platforms will take action against
automated uploading for whatever reason.

The user is responsible for all risks that may be involved by using this tool.
We Flying Upload assume no liability.

�Flying Upload